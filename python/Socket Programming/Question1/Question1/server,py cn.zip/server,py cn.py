import socket
import threading


def send_message():
    while True:
        message = input("")
        message = f"{client_name}: {message}"
        server_socket.sendto(message.encode(), (IP_ADDRESS, PORT))


for i in range(3):
    client_name = input("Enter your name: ")
    client_addresses.append((IP_ADDRESS, PORT+i+1))
    threading.Thread(target=receive_messages).start()
    threading.Thread(target=send_message).start()
